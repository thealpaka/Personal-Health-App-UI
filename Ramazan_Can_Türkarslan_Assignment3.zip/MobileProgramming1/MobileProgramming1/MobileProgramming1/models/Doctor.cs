﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileProgramming1.models
{
    public class Doctor
    {
        public int DoctorID { get; set; }
        public String Name { get; set; }
        public String Profession { get; set; }
        
        public String doctoricon
        {
            get { return @"MobileProgramming1\MobileProgramming1\models\doctor.png"; }
        }
    }
}
