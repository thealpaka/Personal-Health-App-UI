﻿using System;

namespace MobileProgramming1.Table
{
    class regUserTable
    {
        public Guid UserId { get; set; } 
        public string email { get; set; }
        public string password { get; set; }
        public string weight { get; set; }
        public string height { get; set; }

    }
}
