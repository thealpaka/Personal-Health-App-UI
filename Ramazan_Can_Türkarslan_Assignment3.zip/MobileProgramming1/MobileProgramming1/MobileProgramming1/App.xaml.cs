﻿using System;
using MobileProgramming1.views;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MobileProgramming1
{
    public partial class App : Application
    {
        public App()
        {
            Device.SetFlags(new[] { "Brush_Experimental" });

            InitializeComponent();

            MainPage = new NavigationPage(new LoginPage());
        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
