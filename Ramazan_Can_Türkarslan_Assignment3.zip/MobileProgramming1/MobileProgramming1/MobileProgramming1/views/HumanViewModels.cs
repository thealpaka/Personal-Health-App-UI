﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using MobileProgramming1.DataSource;
using MobileProgramming1.models;

namespace MobileProgramming1.views
{
    public class HumanViewModels
    {

        private ObservableCollection<Doctor> humans; 
        public ObservableCollection<Doctor> Humans 
        {
            get { return humans; }
            set
            {
                humans = value;
            }
        }

        public HumanViewModels()
        {

            Humans = new ObservableCollection<Doctor>();

            docinfo _context = new docinfo();

            foreach (var human in _context.docs) 
            {
                Humans.Add(human);
            }
        }


    }
}
