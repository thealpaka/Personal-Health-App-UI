﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MobileProgramming1.Table;
using SQLite;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MobileProgramming1.views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Register : ContentPage
    {
        public Register()
        {

            InitializeComponent();
        }

        private void registerClicked(object sender, EventArgs e)
        {
            var dbpath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), ("UserDatabase.db"));
            var db = new SQLiteConnection(dbpath);
            db.CreateTable<regUserTable>();

            var item = new regUserTable()
            {
                email = Entryemail.Text,
                password = Entrypassword.Text,
                weight = Entryweight.Text,
                height = Entryheight.Text
            };
            db.Insert(item);
            Device.BeginInvokeOnMainThread(async () => {

                var result = await this.DisplayAlert("Great","User Registration Is Successfull", "Yes", "Cancel");

                if (result)
                    await Navigation.PushAsync(new LoginPage());
            });
        }

    }
}