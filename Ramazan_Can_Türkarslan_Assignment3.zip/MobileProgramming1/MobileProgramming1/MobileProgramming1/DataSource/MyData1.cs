﻿using System;
using System.Collections.Generic;
using System.Text;
using MobileProgramming1.models;

namespace MobileProgramming1.DataSource
{
    public class docinfo
    {

        public List<Doctor> docs = new List<Doctor>()
        {
            new Doctor()
            {
                DoctorID = 1,
                Profession = "Brain",
                Name = "Garri Kasparov"
            },
            new Doctor()
            {
                DoctorID = 2,
                Profession = "Psychiatrist",
                Name = "Magnus Carlssen"
            },
            new Doctor()
            {
                DoctorID = 3,
                Profession = "Pediatrician",
                Name = "Alice Coleman"
            },
            new Doctor()
            {
                DoctorID = 4,
                Profession = "Orthodontist",
                Name = "Bergrit Vickersson"
            },
            new Doctor()
            {
                DoctorID = 5,
                Profession = "Optometrist",
                Name = "Mike Wazowski"
            },
            new Doctor()
            {
                DoctorID = 6,
                Profession = "Physician",
                Name = "Omar Al-Hafaari"
            },
            new Doctor()
            {
                DoctorID = 7,
                Profession = "Internal Diseases",
                Name = "Lana Hartman"
            },
            new Doctor()
            {
                DoctorID = 8,
                Profession = "Cardiology",
                Name = "Ege Emir Ozkan"
            },
            new Doctor()
            {
                DoctorID = 9,
                Profession = "Gastroenterology",
                Name = "Murphy Brandy"
            },
            new Doctor()
            {
                DoctorID = 10,
                Profession = "Oncology",
                Name = "Frankie Beans"
            },
        };

    }
}
